WEBSITE MARKETING FIRMANSYAH — VERSI LENGKAP

Fitur:
- Beranda responsif
- Informasi proyek dengan foto/logo yang diberikan
- Program & pelayanan marketing
- Simulasi cicilan (perkiraan)
- Form saran/pertanyaan terhubung WhatsApp
- FAQ
- Tombol telepon dan WhatsApp
- Tombol bagikan website
- SEO dasar
- Tampilan HP/tablet/komputer
- Tanpa database dan tanpa biaya server untuk file statis

Kontak:
Firmansyah
0852-1044-5086

CARA ONLINE GRATIS:
1. Upload seluruh isi folder ke GitHub.
2. Buat repository baru.
3. Upload index.html, style.css, script.js, folder assets.
4. GitHub > Settings > Pages > Deploy from branch > pilih branch utama.
5. Buka alamat GitHub Pages yang diberikan.

CATATAN PENTING:
- Harga, promo, unit tersedia, legalitas, lokasi detail, biaya transaksi, dan ketentuan kredit tidak diada-adakan dalam website.
- Data tersebut sebaiknya dimasukkan setelah ada informasi resmi.
- Simulasi cicilan hanya perkiraan dan bukan penawaran kredit.
