function toggleMenu(){document.getElementById("navMenu").classList.toggle("open")}
document.querySelectorAll("#navMenu a").forEach(a=>a.addEventListener("click",()=>document.getElementById("navMenu").classList.remove("open")));
document.getElementById("year").textContent=new Date().getFullYear();

function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n)}
function calculateInstallment(e){
  e.preventDefault();
  const price=Number(document.getElementById("price").value)||0;
  const dpPct=Number(document.getElementById("dp").value)||0;
  const annual=Number(document.getElementById("rate").value)||0;
  const years=Number(document.getElementById("years").value)||0;
  const dp=price*dpPct/100, principal=Math.max(price-dp,0), n=years*12, r=annual/100/12;
  let monthly=0;
  if(n>0 && principal>0){
    monthly = r===0 ? principal/n : principal*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1);
  }
  const result=document.getElementById("result");
  result.hidden=false;
  result.innerHTML=`<span>Perkiraan DP</span><b>${rupiah(dp)}</b><span>Perkiraan pinjaman</span><b>${rupiah(principal)}</b><span>Perkiraan cicilan / bulan</span><b>${rupiah(monthly)}</b><small>Hasil hanya simulasi matematis. Belum termasuk biaya lain dan bukan persetujuan kredit.</small>`;
}

function sendSuggestion(e){
  e.preventDefault();
  const nama=document.getElementById("nama").value.trim();
  const nomor=document.getElementById("nomor").value.trim();
  const jenis=document.getElementById("jenis").value;
  const pesan=document.getElementById("pesan").value.trim();
  const text=`Halo Pak Firmansyah, saya ${nama}.%0A%0ANomor saya: ${nomor||"-"}%0AJenis: ${jenis}%0A%0APesan: ${pesan}`;
  window.open("https://wa.me/6285210445086?text="+encodeURIComponent(`Halo Pak Firmansyah, saya ${nama}.\n\nNomor saya: ${nomor||"-"}\nJenis: ${jenis}\n\nPesan: ${pesan}`),"_blank");
}
function shareWebsite(){
  if(navigator.share){
    navigator.share({title:"Firmansyah - Marketing & Pemasaran Properti",text:"Informasi marketing properti Firmansyah",url:location.href}).catch(()=>{});
  }else{
    navigator.clipboard?.writeText(location.href);
    alert("Link website sudah disalin jika browser mengizinkannya.");
  }
}
